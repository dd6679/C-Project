﻿namespace VMS.Client2.Net
{
    public enum ApplicationTypes
    {
        AppTypeMaster,
        AppTypeRecording,
        AppTypeDriver,
        AppTypeClient,
        AppTypeManager,
        AppTypeReplayer,
        AppTypeSDK,
        AppTypeCommon = 10,
        AppTypeFederation = 11,
    }

}
