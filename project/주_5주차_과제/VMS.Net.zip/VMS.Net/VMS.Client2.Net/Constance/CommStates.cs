﻿namespace VMS.Client2.Net
{
    public enum CommStates
    {
        Initialized,
        Accepted,
        Authorized,
        Loggedin,
    }
}
