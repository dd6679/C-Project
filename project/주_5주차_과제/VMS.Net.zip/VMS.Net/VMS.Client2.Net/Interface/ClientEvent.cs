﻿namespace VMS.Client2.Net
{
    public interface IClientEvent
    {
        void OnLogin();
        void OnLogout();
    }
}
